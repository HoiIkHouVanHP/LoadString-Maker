﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Octokit;

namespace LoadString_Maker
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {

            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var stringChars = new char[8];
            var random = new Random();
            var github = new GitHubClient(new ProductHeaderValue("GithubCommitTest"));
            var owner = "HoiIkHouVanHP";
            var repo = "scripts";
            var branch = richTextBox1.Text;
            github.Credentials = new Credentials("3b37ae1512be5792cb886f7dff344f42507da978");

            // create file
            var createChangeSet = await github.Repository.Content.CreateFile(owner, repo, "scripts/" + "Loadstring" + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)], new CreateFileRequest("Loadstring Generator", branch));
            string hi = createChangeSet.Content.DownloadUrl;
            textBox1.Text = "loadstring(game:HttpGet(\"" + hi + "\", true))()";
            richTextBox1.Clear();
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBox1.Text);
            button2.Name = "Done";
            await Task.Delay(500);
            button2.Name = "Copy Loadstring";

        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(-1);
        }
    }
}
