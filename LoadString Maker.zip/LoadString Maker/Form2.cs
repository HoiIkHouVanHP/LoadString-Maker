﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PastebinAPI;

namespace LoadString_Maker
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            Pastebin.DevKey = "07ffe986ce4108fe0ffc98a0cb36a197";
            try
            {
                var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                var stringChars = new char[8];
                var random = new Random();

                string code = richTextBox1.Text;
                //creates a new paste and get paste object
                var hi = await Paste.CreateAsync(code, "script" + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)] + chars[random.Next(chars.Length)], Language.HTML5, Visibility.Public, Expiration.Never);
                string url = hi.Url;
                if (url == "Post limit, maximum pastes per 24h reached")
                {
                    MessageBox.Show("Maximum pastes per day reached. Wait 24 hours till u can make new loadstrings");
                }
                else
                {
                    string loadstring = hi.Url.Replace("pastebin.com/", "pastebin.com/raw/");
                    richTextBox1.Text = "loadstring(game:HttpGet(\"" + loadstring + "\", true))()";
                }
            }
            catch
            {
                MessageBox.Show("Ërror");
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(-1);
        }
    }
}
